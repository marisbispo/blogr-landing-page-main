import initDropdownMenu from './modules/dropdown-menu.js';
import initMenuMobile from './modules/menu-mobile.js';

initDropdownMenu();
initMenuMobile();
